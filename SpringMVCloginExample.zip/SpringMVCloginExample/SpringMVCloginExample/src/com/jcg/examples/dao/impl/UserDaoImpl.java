package com.jcg.examples.dao.impl;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.jcg.examples.dao.UserDao;
import com.jcg.examples.viewBean.LoginBean;
import com.mysql.jdbc.Driver;


/**
 * @author CENTAUR
 */
public class UserDaoImpl implements UserDao
{
		DataSource dataSource;
		private Connection connect = null;
		private Statement statement = null;
		private PreparedStatement preparedStatement = null;
		private ResultSet resultSet = null;

		public DataSource getDataSource()
		{
				return this.dataSource;
		}
		
		
		public void setDataSource(DataSource dataSource)
		{
				this.dataSource = dataSource;
		}

//		public static Connection connect() {
//			try {
//				Class.forName("com.mysql.jdbc.Driver");
//				Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "1234");
//				return connect;
//			}
//			catch(Exception e) {
//				System.out.println(e.getMessage());
//			}
//			return null;
//		}
		
		public void readDataBase() throws Exception {
			try {
				// This will load the MySQL driver, each DB has its own driver
				Class.forName("com.mysql.cj.jdbc.Driver");
				// Setup the connection with the DB
				connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb?" + "user=root&password=1234");

				// Statements allow to issue SQL queries to the database
				statement = connect.createStatement();
				// Result set get the result of the SQL query
				resultSet = statement.executeQuery("select * from testdb.userdata");
				while(resultSet.next()) {
					String username = resultSet.getString("username");
		            String password = resultSet.getString("user_password");
		            String name_user = resultSet.getString("name_user");
		            System.out.println(username + " " + password + " " + name_user);
				}
			} catch (Exception e) {
				throw e;
			}
		}
		
		@Override
		public boolean isValidUser(String username, String password) throws SQLException , Exception
		{
				String query = "Select * from userdata where username = '"+ username +"' and user_password = '"+ password + "'";		
				//System.out.println(dataSource.getConnection());
				readDataBase();
				
				
				if(username.equals("abc") && password.equals("123")) {
					return true;
				}
				else{
					return false;
				}

		}


		@Override
		public boolean isExistUser(String username) {
			// TODO Auto-generated method stub
			return false;
		}

}